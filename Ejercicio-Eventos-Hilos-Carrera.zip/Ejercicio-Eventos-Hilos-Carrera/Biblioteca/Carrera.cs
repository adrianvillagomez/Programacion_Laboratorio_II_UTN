﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Biblioteca
{
    public delegate void InformacionDeAvance();
    public delegate void InformacionLlegada(string mensaje);


    /// <summary>
    ///  clase encargada de simular la carrera.
    /// </summary>
    public class Carrera
    {
        //TODO: Declarar el delegado y el evento necesario para informar el avance o la llegada
        //  el evento que informe la llegada debera llevar el la informacion del vehiculo que llego a la meta. Reutilizar ToString()
        public event Action InformarAvance;
        public event Action<string> InformarLlegada;


        List<AutoF1> autos;
        int kms;

        public Carrera()
        {
            autos = new List<AutoF1>();
        }

        public Carrera(int kms) : this()
        {
            this.kms = kms;
        }

        public List<AutoF1> Autos { get => autos; set => autos = value; }
        public int Kms { get => kms; set => kms = value; }


        //TODO: El método Iniciar carrera será ejecutado en un hilo secundario y deberá:
        //        i.Se deberá iterar hasta que todos los autos se les haya asignado
        //posición.
        //ii.Recorrer la lista de vehículos de la carrera, acelerar cada
        //vehículo.
        //iii.Informar avance del vehículo.
        //iv.Realizar un Sleep de 10 milisegundos.
        //v.Si la ubicación en pista del vehículo es mayor a Kms de carrera y
        //la posición del Auto aun no fue asignada:
        //1. Se asignará la posición de llegada del vehículo, al ganador
        //se le asignará 1 y al siguiente 2, etc.
        //2. Se informará la llegada del vehículo a la meta, reutilizar el
        //ToString de AutoF1
        public void IniciarCarrera()
        {

            

        }
        public static Carrera operator +(Carrera c, AutoF1 a)
        {
            c.Autos.Add(a);
            return c;
        }
    }
}
